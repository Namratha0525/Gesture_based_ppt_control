# Android Integration Guide — Gesture Recognition
## Assets (copy to app/src/main/assets/)
- gesture_model_quant.tflite   ← Use this for inference
- labels.txt                   ← 6 classes, one per line
- scaler_params.json           ← StandardScaler mean + scale arrays

## Inference Pipeline (Java/Kotlin)
1. Initialize MediaPipe HandsLandmarker (hand_landmarker.task)
2. On each frame: extract 21 landmarks → flatten to float[63]
3. Compute engineered features (see Python extract_features() — port to Kotlin)
4. Apply StandardScaler: feature[i] = (feature[i] - mean[i]) / scale[i]
5. Feed float[94] to TFLite interpreter
6. argmax(output) → class index → look up labels.txt
7. Map class to UI action:
   - open_palm   → show menu / pause
   - closed_fist → select / click
   - pinch       → zoom in
   - peace       → screenshot / back
   - swipe_right → next page / swipe right
   - swipe_left  → previous page / swipe left

## Feature Count
  Input to TFLite: 94 features
  (63 raw landmarks + 15 joint angles + 10 tip-wrist dist + 5 tip-thumb dist + 6 key distances)

## TFLite Input Shape
  [1, 94]
